const state = {
  rangeDays: 7,
  startDate: null,
  endDate: null,
  markets: [],
  history: [],
  charts: {
    line: null,
    bar: null,
    area: null,
    donut: null
  }
};

const elements = {
  statsGrid: document.getElementById("statsGrid"),
  assetTableBody: document.getElementById("assetTableBody"),
  apiStatus: document.getElementById("apiStatus"),
  lastUpdatedText: document.getElementById("lastUpdatedText"),
  selectedRangeLabel: document.getElementById("selectedRangeLabel"),
  themeToggle: document.getElementById("themeToggle"),
  startDate: document.getElementById("startDate"),
  endDate: document.getElementById("endDate"),
  applyDateRange: document.getElementById("applyDateRange"),
  downloadCsv: document.getElementById("downloadCsv"),
  downloadJson: document.getElementById("downloadJson"),
  rangeButtons: document.querySelectorAll(".range-btn")
};

const formatCurrency = value =>
  new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 0
  }).format(value);

const formatCompactCurrency = value =>
  new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    notation: "compact",
    maximumFractionDigits: 2
  }).format(value);

const formatCompactNumber = value =>
  new Intl.NumberFormat("en-US", {
    notation: "compact",
    maximumFractionDigits: 2
  }).format(value);

const formatPercent = value => `${value >= 0 ? "+" : ""}${Number(value).toFixed(2)}%`;

const formatDate = value =>
  new Date(value).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric"
  });

const formatDateTime = value =>
  new Date(value).toLocaleString("en-US", {
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit"
  });

const today = new Date();
const ninetyDaysAgo = new Date();
ninetyDaysAgo.setDate(today.getDate() - 90);

function toInputDate(date) {
  const d = new Date(date);
  const month = `${d.getMonth() + 1}`.padStart(2, "0");
  const day = `${d.getDate()}`.padStart(2, "0");
  return `${d.getFullYear()}-${month}-${day}`;
}

function setDefaultDates(days) {
  const end = new Date();
  const start = new Date();
  start.setDate(end.getDate() - days);
  state.startDate = start;
  state.endDate = end;
  elements.startDate.value = toInputDate(start);
  elements.endDate.value = toInputDate(end);
}

function getThemeTextColor() {
  return getComputedStyle(document.body).getPropertyValue("--text").trim();
}

function getThemeGridColor() {
  return document.body.classList.contains("dark")
    ? "rgba(148, 163, 184, 0.14)"
    : "rgba(15, 23, 42, 0.08)";
}

function getTooltipBackground() {
  return document.body.classList.contains("dark") ? "#020617" : "#111827";
}

function updateRangeLabel() {
  const diff = Math.max(
    1,
    Math.ceil((state.endDate.getTime() - state.startDate.getTime()) / 86400000)
  );
  elements.selectedRangeLabel.textContent = `${diff} Day Range`;
}

function renderStats() {
  if (!state.markets.length || !state.history.length) {
    return;
  }

  const totalMarketCap = state.markets.reduce((sum, item) => sum + item.market_cap, 0);
  const totalVolume = state.markets.reduce((sum, item) => sum + item.total_volume, 0);
  const averageChange =
    state.markets.reduce((sum, item) => sum + item.price_change_percentage_24h, 0) /
    state.markets.length;

  const bestPerformer = [...state.markets].sort(
    (a, b) => b.price_change_percentage_24h - a.price_change_percentage_24h
  )[0];

  const currentPrice = state.history[state.history.length - 1]?.[1] || 0;
  const previousPrice = state.history[0]?.[1] || 0;
  const selectedRangeChange = previousPrice
    ? ((currentPrice - previousPrice) / previousPrice) * 100
    : 0;

  const stats = [
    {
      label: "Total Market Cap",
      value: formatCompactCurrency(totalMarketCap),
      change: formatPercent(averageChange),
      trend: averageChange >= 0 ? "positive" : "negative",
      icon: "MC"
    },
    {
      label: "Total 24H Volume",
      value: formatCompactCurrency(totalVolume),
      change: `${formatCompactNumber(totalVolume)} traded`,
      trend: "neutral",
      icon: "VL"
    },
    {
      label: "Range Performance",
      value: formatPercent(selectedRangeChange),
      change: `${formatCurrency(currentPrice)} current BTC`,
      trend: selectedRangeChange >= 0 ? "positive" : "negative",
      icon: "BT"
    },
    {
      label: "Top Performer",
      value: bestPerformer ? bestPerformer.symbol.toUpperCase() : "--",
      change: bestPerformer ? formatPercent(bestPerformer.price_change_percentage_24h) : "--",
      trend:
        bestPerformer && bestPerformer.price_change_percentage_24h >= 0
          ? "positive"
          : "negative",
      icon: "TP"
    }
  ];

  elements.statsGrid.innerHTML = stats
    .map(
      item => `
        <article class="stat-card">
          <div class="stat-copy">
            <span class="stat-label">${item.label}</span>
            <strong class="stat-value">${item.value}</strong>
            <span class="stat-change ${item.trend}">${item.change}</span>
          </div>
          <div class="stat-icon">${item.icon}</div>
        </article>
      `
    )
    .join("");
}

function renderTable() {
  if (!state.markets.length) {
    elements.assetTableBody.innerHTML = `
      <tr>
        <td colspan="5">No market data available.</td>
      </tr>
    `;
    return;
  }

  elements.assetTableBody.innerHTML = state.markets
    .map(
      item => `
        <tr>
          <td>
            <div class="asset-cell">
              <img src="${item.image}" alt="${item.name}" class="asset-avatar" />
              <div class="asset-meta">
                <span class="asset-name">${item.name}</span>
                <span class="asset-symbol">${item.symbol}</span>
              </div>
            </div>
          </td>
          <td>${formatCurrency(item.current_price)}</td>
          <td class="${item.price_change_percentage_24h >= 0 ? "positive" : "negative"}">${formatPercent(item.price_change_percentage_24h)}</td>
          <td>${formatCompactCurrency(item.market_cap)}</td>
          <td>${formatCompactCurrency(item.total_volume)}</td>
        </tr>
      `
    )
    .join("");
}

function destroyCharts() {
  Object.keys(state.charts).forEach(key => {
    if (state.charts[key]) {
      state.charts[key].destroy();
      state.charts[key] = null;
    }
  });
}

function buildCharts() {
  if (!state.history.length || !state.markets.length) {
    return;
  }

  destroyCharts();

  const historyLabels = state.history.map(point => formatDate(point[0]));
  const historyPrices = state.history.map(point => Number(point[1].toFixed(2)));
  const marketLabels = state.markets.map(item => item.symbol.toUpperCase());
  const marketCaps = state.markets.map(item => item.market_cap);
  const volumes = state.markets.map(item => item.total_volume);

  state.charts.line = new Chart(document.getElementById("lineChart"), {
    type: "line",
    data: {
      labels: historyLabels,
      datasets: [
        {
          label: "BTC Price",
          data: historyPrices,
          borderColor: "#4f46e5",
          backgroundColor: "rgba(79,70,229,0.16)",
          tension: 0.35,
          fill: false,
          pointRadius: 0,
          pointHoverRadius: 5,
          borderWidth: 3
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      animation: {
        duration: 1000,
        easing: "easeOutQuart"
      },
      interaction: {
        mode: "index",
        intersect: false
      },
      plugins: {
        legend: {
          display: false
        },
        tooltip: {
          backgroundColor: getTooltipBackground(),
          padding: 12,
          displayColors: false,
          callbacks: {
            label: context => ` ${formatCurrency(context.raw)}`
          }
        }
      },
      scales: {
        x: {
          ticks: {
            color: getThemeTextColor(),
            maxTicksLimit: 8
          },
          grid: {
            color: getThemeGridColor()
          }
        },
        y: {
          ticks: {
            color: getThemeTextColor(),
            callback: value => formatCompactCurrency(value)
          },
          grid: {
            color: getThemeGridColor()
          }
        }
      }
    }
  });

  state.charts.bar = new Chart(document.getElementById("barChart"), {
    type: "bar",
    data: {
      labels: marketLabels,
      datasets: [
        {
          label: "Market Cap",
          data: marketCaps,
          borderRadius: 12,
          borderSkipped: false,
          backgroundColor: ["#4f46e5", "#06b6d4", "#10b981", "#f59e0b", "#ef4444", "#8b5cf6"]
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      animation: {
        duration: 1200,
        easing: "easeOutBounce"
      },
      plugins: {
        legend: {
          display: false
        },
        tooltip: {
          backgroundColor: getTooltipBackground(),
          padding: 12,
          callbacks: {
            label: context => ` ${formatCompactCurrency(context.raw)}`
          }
        }
      },
      scales: {
        x: {
          ticks: {
            color: getThemeTextColor()
          },
          grid: {
            display: false
          }
        },
        y: {
          ticks: {
            color: getThemeTextColor(),
            callback: value => formatCompactCurrency(value)
          },
          grid: {
            color: getThemeGridColor()
          }
        }
      }
    }
  });

  state.charts.area = new Chart(document.getElementById("areaChart"), {
    type: "line",
    data: {
      labels: historyLabels,
      datasets: [
        {
          label: "BTC Area Trend",
          data: historyPrices,
          borderColor: "#06b6d4",
          backgroundColor: "rgba(6,182,212,0.18)",
          tension: 0.35,
          fill: true,
          pointRadius: 0,
          pointHoverRadius: 5,
          borderWidth: 2.5
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      animation: {
        duration: 1000,
        easing: "easeOutQuart"
      },
      interaction: {
        mode: "index",
        intersect: false
      },
      plugins: {
        legend: {
          display: false
        },
        tooltip: {
          backgroundColor: getTooltipBackground(),
          padding: 12,
          displayColors: false,
          callbacks: {
            label: context => ` ${formatCurrency(context.raw)}`
          }
        }
      },
      scales: {
        x: {
          ticks: {
            color: getThemeTextColor(),
            maxTicksLimit: 8
          },
          grid: {
            color: getThemeGridColor()
          }
        },
        y: {
          ticks: {
            color: getThemeTextColor(),
            callback: value => formatCompactCurrency(value)
          },
          grid: {
            color: getThemeGridColor()
          }
        }
      }
    }
  });

  state.charts.donut = new Chart(document.getElementById("donutChart"), {
    type: "doughnut",
    data: {
      labels: marketLabels,
      datasets: [
        {
          data: volumes,
          backgroundColor: ["#4f46e5", "#06b6d4", "#10b981", "#f59e0b", "#ef4444", "#8b5cf6"],
          borderWidth: 0,
          hoverOffset: 8
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      animation: {
        duration: 1000,
        easing: "easeOutQuart"
      },
      plugins: {
        legend: {
          position: "bottom",
          labels: {
            color: getThemeTextColor(),
            usePointStyle: true,
            boxWidth: 8,
            boxHeight: 8,
            padding: 18
          }
        },
        tooltip: {
          backgroundColor: getTooltipBackground(),
          padding: 12,
          callbacks: {
            label: context => ` ${context.label}: ${formatCompactCurrency(context.raw)}`
          }
        }
      }
    }
  });
}

async function fetchMarkets() {
  const url =
    "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=6&page=1&sparkline=false&price_change_percentage=24h";
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error("Unable to fetch market data");
  }
  return response.json();
}

async function fetchHistory() {
  const from = Math.floor(state.startDate.getTime() / 1000);
  const to = Math.floor(state.endDate.getTime() / 1000);
  const url = `https://api.coingecko.com/api/v3/coins/bitcoin/market_chart/range?vs_currency=usd&from=${from}&to=${to}`;
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error("Unable to fetch historical data");
  }
  const data = await response.json();
  return data.prices || [];
}

async function loadDashboard() {
  try {
    elements.apiStatus.textContent = "Syncing live market API";
    elements.lastUpdatedText.textContent = "Refreshing dashboard data";

    const [markets, history] = await Promise.all([fetchMarkets(), fetchHistory()]);

    state.markets = markets;
    state.history = history;

    renderStats();
    renderTable();
    buildCharts();
    updateRangeLabel();

    elements.apiStatus.textContent = "Live API connected";
    elements.lastUpdatedText.textContent = `Last updated ${formatDateTime(new Date())}`;
  } catch (error) {
    elements.apiStatus.textContent = "API unavailable";
    elements.lastUpdatedText.textContent = "Unable to load live data";

    elements.statsGrid.innerHTML = `
      <article class="stat-card">
        <div class="stat-copy">
          <span class="stat-label">Error</span>
          <strong class="stat-value">Data Load Failed</strong>
          <span class="stat-change negative">${error.message}</span>
        </div>
        <div class="stat-icon">ER</div>
      </article>
    `;

    elements.assetTableBody.innerHTML = `
      <tr>
        <td colspan="5">Unable to load data from the live API right now. Please try again.</td>
      </tr>
    `;

    destroyCharts();
  }
}

function buildCsv() {
  const rows = [
    ["Name", "Symbol", "Price", "24H Change", "Market Cap", "24H Volume"],
    ...state.markets.map(item => [
      item.name,
      item.symbol.toUpperCase(),
      item.current_price,
      item.price_change_percentage_24h,
      item.market_cap,
      item.total_volume
    ])
  ];

  return rows
    .map(row =>
      row
        .map(value => `"${String(value).replace(/"/g, '""')}"`)
        .join(",")
    )
    .join("\n");
}

function downloadFile(filename, content, type) {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

function downloadCsvReport() {
  downloadFile("datavista-report.csv", buildCsv(), "text/csv;charset=utf-8;");
}

function downloadJsonReport() {
  const payload = {
    generatedAt: new Date().toISOString(),
    range: {
      start: state.startDate.toISOString(),
      end: state.endDate.toISOString()
    },
    markets: state.markets,
    history: state.history
  };

  downloadFile("datavista-report.json", JSON.stringify(payload, null, 2), "application/json");
}

function setActiveRangeButton(days) {
  elements.rangeButtons.forEach(button => {
    button.classList.toggle(Number(button.dataset.range) === days, true);
    if (Number(button.dataset.range) !== days) {
      button.classList.remove("active");
    }
  });
}

function validateDates() {
  if (!elements.startDate.value || !elements.endDate.value) {
    return null;
  }

  const start = new Date(elements.startDate.value);
  const end = new Date(elements.endDate.value);

  if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime())) {
    return null;
  }

  if (start > end) {
    return null;
  }

  if (start < ninetyDaysAgo || end > today) {
    return null;
  }

  return { start, end };
}

elements.rangeButtons.forEach(button => {
  button.addEventListener("click", () => {
    const days = Number(button.dataset.range);
    state.rangeDays = days;

    elements.rangeButtons.forEach(btn => btn.classList.remove("active"));
    button.classList.add("active");

    setDefaultDates(days);
    loadDashboard();
  });
});

elements.applyDateRange.addEventListener("click", () => {
  const dates = validateDates();

  if (!dates) {
    alert("Please choose a valid date range within the last 90 days.");
    return;
  }

  state.startDate = dates.start;
  state.endDate = dates.end;
  elements.rangeButtons.forEach(button => button.classList.remove("active"));
  loadDashboard();
});

elements.themeToggle.addEventListener("click", () => {
  document.body.classList.toggle("dark");
  elements.themeToggle.textContent = document.body.classList.contains("dark")
    ? "Light Mode"
    : "Dark Mode";

  if (state.history.length && state.markets.length) {
    buildCharts();
  }
});

elements.downloadCsv.addEventListener("click", downloadCsvReport);
elements.downloadJson.addEventListener("click", downloadJsonReport);

setDefaultDates(state.rangeDays);
loadDashboard();